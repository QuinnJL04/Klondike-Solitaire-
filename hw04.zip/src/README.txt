Moved all of basic klondike into an abstract class called abstract klondike.

I then extended this abstract class in all my models.

I fixed my movePile and moveDraw to handle the empty pile case.

Broke up long methods into helpers.