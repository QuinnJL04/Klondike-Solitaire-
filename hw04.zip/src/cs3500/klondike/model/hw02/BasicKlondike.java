package cs3500.klondike.model.hw02;


import cs3500.klondike.model.hw04.AbstractKlondike;

/**
 * Represents a BasicKlondike game which is divided into cascade, foundation, and draw piles.
 */
public class BasicKlondike extends AbstractKlondike {

}
